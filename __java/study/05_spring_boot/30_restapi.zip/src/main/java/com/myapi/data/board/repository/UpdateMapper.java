package com.myapi.data.board.repository;

import org.apache.ibatis.annotations.Mapper;

import com.myapi.data.board.domain.BoardVO;

@Mapper
public interface UpdateMapper {
	int insert(BoardVO bvo);
	int update(BoardVO bvo);
	int updateY(Long bno);
	// 추가될 서비스의 쿼리 메서드
}
