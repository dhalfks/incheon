package com.myapi.data.board.service;

import com.myapi.data.board.domain.BoardVO;

public interface UpdateService {
	int register(BoardVO bvo);
	int modify(BoardVO bvo);
	int removeY(Long bno);
	// 추가될 주요 서비스 메서드
}
