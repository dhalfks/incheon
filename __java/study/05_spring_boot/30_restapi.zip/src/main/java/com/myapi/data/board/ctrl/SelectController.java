package com.myapi.data.board.ctrl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.myapi.data.board.domain.BoardVO;
import com.myapi.data.board.service.SelectService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/board")
public class SelectController {
	@Autowired
	private SelectService service;
	
	@GetMapping("")
	public List<BoardVO> list(Model model) {
		log.debug(">>> rest api - list");
		return service.getList();
	}
	@GetMapping("/{bno}")
	public BoardVO byBno(@PathVariable("bno") Long bno) {
		log.debug(">>> rest api - byBno : ", bno);
		return service.getByBno(bno);
	}
	@GetMapping("/id/{regId}")
	public List<BoardVO> byRegId(@PathVariable("regId") String regId){
		log.debug(">>> rest api - byRegId", regId);
		return service.getByRegId(regId);
	}
}
