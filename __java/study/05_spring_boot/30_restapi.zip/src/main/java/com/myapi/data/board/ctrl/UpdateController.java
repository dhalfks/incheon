package com.myapi.data.board.ctrl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.myapi.data.board.domain.BoardVO;
import com.myapi.data.board.service.UpdateService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/board")
public class UpdateController {
	@Autowired
	private UpdateService service;
	
	@PostMapping("/register")
	public String register(@RequestBody BoardVO bvo) {
		return service.register(bvo) > 0 ? "ok":"fail";
	}
	
	@PutMapping("/{bno}")
	public String modify(@RequestBody BoardVO bvo) {
		return service.modify(bvo) > 0 ? "ok" : "fail";
	}
	@DeleteMapping("/{bno}")
	public String remove(@PathVariable("bno") Long bno) {
		return service.removeY(bno) > 0 ? "ok" : "fail";
	}

}
