package com.myapi.data.board.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.myapi.data.board.domain.BoardVO;
import com.myapi.data.board.repository.SelectMapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class SelectServiceImpl implements SelectService {
	@Autowired
	private SelectMapper mapper;
	
	@Override
	public List<BoardVO> getList() {
		return mapper.selectList();
	}

	@Override
	public BoardVO getByBno(Long bno) {
		return mapper.selectByBno(bno);
	}

	@Override
	public List<BoardVO> getByRegId(String regId) {
		return mapper.selectByRegId(regId);
	}

}
