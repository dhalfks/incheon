package com.myapi.data.board.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.myapi.data.board.domain.BoardVO;

@Mapper
public interface SelectMapper {
	List<BoardVO> selectList();
	BoardVO selectByBno(Long bno);
	List<BoardVO> selectByRegId(String regId);
	// select 할 정보에 따른 주요 쿼리 메서드 구축
}
