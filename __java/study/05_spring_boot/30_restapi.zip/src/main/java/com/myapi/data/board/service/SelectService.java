package com.myapi.data.board.service;

import java.util.List;

import com.myapi.data.board.domain.BoardVO;

public interface SelectService {
	List<BoardVO> getList();
	BoardVO getByBno(Long bno);
	List<BoardVO> getByRegId(String regId);
	// select 할 정보에 따른 주요 서비스 메서드 구축
}
