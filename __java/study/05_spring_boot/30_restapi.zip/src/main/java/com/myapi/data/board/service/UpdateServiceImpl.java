package com.myapi.data.board.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.myapi.data.board.domain.BoardVO;
import com.myapi.data.board.repository.UpdateMapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class UpdateServiceImpl implements UpdateService {
	@Autowired
	private UpdateMapper mapper;
	
	@Override
	public int register(BoardVO bvo) {
		return mapper.insert(bvo);
	}

	@Override
	public int modify(BoardVO bvo) {
		return mapper.update(bvo);
	}

	@Override
	public int removeY(Long bno) {
		return mapper.updateY(bno);
	}

}
