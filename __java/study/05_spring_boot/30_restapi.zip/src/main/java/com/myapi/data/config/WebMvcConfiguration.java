package com.myapi.data.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Configuration
public class WebMvcConfiguration implements WebMvcConfigurer {
	// 파일, 인코딩 등의 설정 메서드 추가
	// CommonMultipartResolver, CharacterEncodingFilter (부트 2.1 부터 기본적용)	
}
