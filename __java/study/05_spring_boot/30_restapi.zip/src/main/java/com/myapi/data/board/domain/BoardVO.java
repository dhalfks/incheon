package com.myapi.data.board.domain;

import org.apache.ibatis.type.Alias;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Data
@Alias("bvo")
public class BoardVO {
	private Long bno;
	private String title;
	private String content;
	private Integer readCount;
	private String regId;
	private String regDate;
	private String modId;
	private String modDate;
	private String isRemoved;
}
