drop table if exists t_board;

create table if not exists t_board (
bno bigint not null auto_increment,
title varchar(200) not null,
content text not null,
read_count int not null default 0,
reg_id varchar(50) not null,
reg_date datetime not null default current_timestamp(),
mod_id varchar(50) default null,
mod_date datetime not null default current_timestamp(),
is_removed char(1) not null default 'N',
primary key(bno)
);