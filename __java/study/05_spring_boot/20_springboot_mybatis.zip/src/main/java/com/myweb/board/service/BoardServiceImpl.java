package com.myweb.board.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.myweb.board.dto.BoardDTO;
import com.myweb.board.repository.BoardMapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class BoardServiceImpl implements BoardService {
	@Autowired
	private BoardMapper mapper;
	@Override
	public void register(BoardDTO bdto) throws Exception {
		mapper.insert(bdto);
	}
	@Override
	public List<BoardDTO> getList() throws Exception {
		return mapper.selectList();
	}
	
	@Override
	public BoardDTO getDetail(Long pno) throws Exception {
		mapper.updateRC(pno);
		return mapper.selectOne(pno);
	}
	@Override
	public void modify(BoardDTO bdto) throws Exception {
		mapper.update(bdto);
	}
	@Override
	public void remove(Long pno) throws Exception {
		mapper.delete(pno);
	}

}
