package com.myweb.board.repos;

import java.util.stream.IntStream;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.myweb.board.entity.Board;
import com.myweb.board.repository.BoardRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@SpringBootTest
public class BoardReposTest {
	
	@Autowired
	private BoardRepository boardRepos;
	
	@Test
	public void insertDummyTest() {
//		for (int j = 0; j < 1000; j++) {
//			Board board = new Board();
//			board.setTitle("This is Title of " + j);
//			board.setContent("This Content of " + j);
//			board.setWriter("Tester"+j+"@tester.com");
//			boardRepos.save(board);
//		}
		
		IntStream.rangeClosed(1, 1000).forEach(i->{
			Board board = Board.builder()
					.title("This is Title of " + i)
					.content("This Content of " + i)
					.writer("Tester"+i+"@tester.com").build();
			log.info(">>> {}", boardRepos.save(board));
		});
	}

}
